<?php $__env->startSection('title', 'Confirm Password'); ?>

<?php $__env->startSection('content'); ?>
<div class="wrapper account-verification">
    <div class="container-fluid">

        <div class="row align-items-center">


            <div class="col-lg-4 ps-0 pe-0">
                <div class="form-side-display d-flex justify-content-center align-items-center">
                    <a href="<?php echo e(route('frontend.home')); ?>" class="d-inline-block">
                        <div class="form-side-logo mb-2">
                            <img src="<?php echo e(asset('/assets/frontend/img/Logo-Computerkopen.png')); ?>" alt="logo" class="img-fluid"/>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-lg-8 ps-0 pe-0  forms-h">
                <div class="login-main">
                    <div class="login-main-content">
                        <h2><h2>Confirm Password</h2></h2>
                        <form method="POST" action="<?php echo e(route('password.update')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="token" value="<?php echo e($token); ?>">
                            <div class="mb-3 login-form-input">
                                <input placeholder="Email" id="email" type="email"
                                class="input_email form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                                value="<?php echo e($email ?? old('email')); ?>" required autocomplete="email" autofocus readonly>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="login-form-input form-password-eye-box mb-3">
                                <input type="password" value="<?php echo e(old('password')); ?>" name="password" class="form-control pe-5 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " placeholder="Password" id="exampleInputPassword1" required>
                                <span class="form-password-eye" id="passwordVis" onclick="passwordVisibility()">
                                    <i class="fa fa-eye" id="eyeopened" aria-hidden="true"></i>
                                </span>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="login-form-input form-password-eye-box mb-3">
                                <input type="password" value="<?php echo e(old('password_confirmation')); ?>" name="password_confirmation" class="input_password form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> signup_pass pe-5" placeholder="Confirm Password" id="exampleInputPassword2">
                                <span class="form-password-eye" id="passwordVis" onclick="passwordConfirm()">
                                    <i class="fa fa-eye" id="eyeopened" aria-hidden="true"></i>
                                </span>
                                <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                            <button type="submit" class="btn mb-3 main-btn w-100">Reset Password</button>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>


<script>
    $(document).ready(function() {
        $("#show_hide_password").on('click', function(event) {
            event.preventDefault();
            if($('#password input').attr("type") == "text"){
                $('#password input').attr('type', 'password');
                $('#password #show_hide_password').addClass( "fa-eye-slash" );
                $('#password #show_hide_password').removeClass( "fa-eye" );
            }else if($('#password input').attr("type") == "password"){
                $('#password input').attr('type', 'text');
                $('#password #show_hide_password').removeClass( "fa-eye-slash" );
                $('#password #show_hide_password').addClass( "fa-eye" );
            }
        });

        $("#conf_show_hide_password").on('click', function(event) {
            event.preventDefault();
            if ($('#conf_password input').attr("type") == "text") {
                $('#conf_password input').attr('type', 'password');
                $('#conf_password #conf_show_hide_password').addClass("fa-eye-slash");
                $('#conf_password #conf_show_hide_password').removeClass("fa-eye");
            } else if ($('#conf_password input').attr("type") == "password") {
                $('#conf_password input').attr('type', 'text');
                $('#conf_password #conf_show_hide_password').removeClass("fa-eye-slash");
                $('#conf_password #conf_show_hide_password').addClass("fa-eye");
            }
        });
    });
</script>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\harun mia\Documents\GitHub\ComputerProject\resources\views/auth/passwords/reset.blade.php ENDPATH**/ ?>