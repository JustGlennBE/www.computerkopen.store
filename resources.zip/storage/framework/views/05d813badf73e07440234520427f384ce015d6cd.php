<?php $__env->startSection('title', 'Email Verification'); ?>

<?php $__env->startSection('content'); ?>
<div class="faqs">
    <banner class="faqs-banner">
        <div class="image">
            <img src="<?php echo e(asset('/assets/frontend/img/email.svg')); ?>" alt="faqs" class="img-fluid" />
        </div>
    </banner>
    <div class="email-check faqs-body pb-5">
        <div class="container content">
            <?php if(session('resent')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

                </div>
            <?php endif; ?>
            <h1>Email Confirmation</h1>
            <p>Hey <strong>JustGlennbe,</strong> you are almost ready to start enjoying ComputerKopen. </p>
            <p class="mb-md-5 mb-3">Simply click the below button to verify your email. Once you verify, You will have you will recover your Password.</p>
            <form method="POST" action="<?php echo e(route('verification.resend')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-main">Confirm Email</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\harun mia\Documents\GitHub\ComputerProject\resources\views/auth/verify.blade.php ENDPATH**/ ?>