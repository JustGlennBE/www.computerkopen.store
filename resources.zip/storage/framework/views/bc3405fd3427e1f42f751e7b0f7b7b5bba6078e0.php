

<?php $__env->startSection('content'); ?>
<div class="wrapper account-verification">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-lg-4 ps-0 pe-0">
                <div class="form-side-display d-flex justify-content-center align-items-center">
                    <a href="<?php echo e(route('frontend.home')); ?>" class="d-inline-block">
                        <div class="form-side-logo mb-2">
                            <img src="<?php echo e(asset('/assets/frontend/img/Logo-Computerkopen.png')); ?>" alt="logo" class="img-fluid"/>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-lg-8 ps-0 pe-0  forms-h">
                <div class="login-main">
                    <div class="login-main-content">
                        <strong class="para-light">Welcome Back</strong>
                        <h2>Login to your Account</h2>
                        <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3 login-form-input">
                                    <input placeholder="Email" id="email" type="email" class="input_email form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3 login-form-input form-password-eye-box">
                                <div class="input_text" id="password">
                                    <input type="password" value="<?php echo e(old('password')); ?>" name="password" class="input_password form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> signup_pass" placeholder="Password" autocomplete="current-password" required>
                                    <span class="form-password-eye" id="passwordVis" onclick="passwordVisibility()">
                                        <i class="fa fa-eye" id="show_hide_password" aria-hidden="true"></i>
                                    </span>
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="mb-4 form-check d-flex justify-content-between">
                                <span>
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="remember"><?php echo e(__('Remember Me')); ?></label>
                                </span>
                                <a href="<?php echo e(route('password.request')); ?>" class="form-link-a" id="forget-password">Forget Password?</a>
                            </div>
                            <button type="submit" class="btn mb-3 main-btn w-100">Login</button>
                            <div>
                                <a href="<?php echo e(route('register')); ?>" id="register-new-user" class="form-link-a">Register As New User</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
    $("#show_hide_password").on('click', function(event) {
        event.preventDefault();
        if($('#password input').attr("type") == "text"){
            $('#password input').attr('type', 'password');
            $('#password #show_hide_password').addClass( "fa-eye-slash" );
            $('#password #show_hide_password').removeClass( "fa-eye" );
        }else if($('#password input').attr("type") == "password"){
            $('#password input').attr('type', 'text');
            $('#password #show_hide_password').removeClass( "fa-eye-slash" );
            $('#password #show_hide_password').addClass( "fa-eye" );
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\harun mia\Documents\GitHub\ComputerProject\resources\views/auth/login.blade.php ENDPATH**/ ?>