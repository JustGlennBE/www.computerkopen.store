<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="description">
    <meta content="" name="keywords">

    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title', config('app.name', 'Laravel')); ?> - <?php echo e(config('app.name', 'Laravel')); ?></title>

    
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    
    <script src="<?php echo e(asset('assets/frontend/js/jquery.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('assets/frontend/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/frontend/js/bootstrap.min.js')); ?>"></script>

    
    <link href="<?php echo e(asset('css/toastr/toastr.min.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('css/toastr/toastr.min.js')); ?>"></script>

    
    <link href="<?php echo e(asset('assets/frontend/img/favicon.png')); ?>" rel="icon">
    <link href="<?php echo e(asset('assets/frontend/img/apple-touch-icon.png')); ?>" rel="apple-touch-icon">
    <link href="<?php echo e(asset('assets/frontend/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/frontend/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/frontend/css/style.css')); ?>" rel="stylesheet">

    
    <?php echo $__env->yieldPushContent('third_party_stylesheets'); ?>
    <?php echo $__env->yieldPushContent('page_css'); ?>

</head>
<body>

    
    <?php echo $__env->yieldContent('content'); ?>

    
    <?php echo $__env->yieldPushContent('third_party_scripts'); ?>
    <?php echo $__env->yieldPushContent('page_scripts'); ?>

    <script>
        <?php if(session('success')): ?>
            toastr.success("<?php echo e(session('success')); ?>");
        <?php endif; ?>

        <?php if(session('error')): ?>
            toastr.error("<?php echo e(session('error')); ?>");
        <?php endif; ?>

        <?php if(Session::has('info')): ?>
            toastr.info("<?php echo e(session('info')); ?>");
        <?php endif; ?>

        <?php if(Session::has('warning')): ?>
            toastr.warning("<?php echo e(session('warning')); ?>");
        <?php endif; ?>
    </script>

    
    <script src="<?php echo e(asset('assets/frontend/js/custom.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Users\harun mia\Documents\GitHub\ComputerProject\resources\views/layouts/auth.blade.php ENDPATH**/ ?>